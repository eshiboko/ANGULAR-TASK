export enum Size {
  SMALL = "small",
  MEDIUM = "medium",
  LARGE = "large",
  // TODO refactor to object?
}
